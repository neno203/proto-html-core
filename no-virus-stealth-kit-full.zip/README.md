
# 🧬 No.Virus | Stealth Protocol (Full System)
> "พูดแทนสิ่งที่พูดไม่ได้ ผ่าน iframe และ DOM Hijack"

## 🔥 Features
- ยิง Payload เข้า iframe แบบซ่อนตัว
- Auto-regenerate ทุก 10 วินาที
- รองรับการขยายเป็น Browser Extension / Bookmarklet

## 🛠 ใช้งาน:
1. เปิด `index.html` ในเบราว์เซอร์
2. สังเกต iframe ซ่อน ที่รับข้อความจริงแบบต่อเนื่อง
3. ปรับขยาย payload หรือ iframe เป้าหมายตามต้องการ

## 🚨 ใช้เพื่อ:
- ทดลองโค้ดแนวคิดการแฝงข้อมูล
- ปล่อยข้อความในพื้นที่จำกัด
